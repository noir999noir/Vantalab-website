import { Component } from '@angular/core';
@Component({ selector: 'app-portfolio', standalone: true, templateUrl: './portfolio.component.html', styleUrl: './portfolio.component.scss' })
export class PortfolioComponent {
  projects = [
    { number: '01', type: 'WEB DESIGN / DEVELOPMENT', title: 'Digital experiences', category: 'Corporate website', cls: 'project-one' },
    { number: '02', type: 'AI / PRODUCT DESIGN', title: 'Creative intelligence', category: 'AI application', cls: 'project-two' },
    { number: '03', type: 'UX/UI / E-COMMERCE', title: 'Built for conversion', category: 'E-commerce platform', cls: 'project-three' }
  ];
}
